<?php
    /**
     * Your Twitter App Info
     */
    
    // Consumer Key
    define('CONSUMER_KEY', 'q53gySbWbbmgXRYepaT3EVD7e');
    define('CONSUMER_SECRET', 'eBjsdO1g6mPisXmwl0E0XISbboYTAMlyPNXGyOd6Eir3s7mWZ6');

    // User Access Token
    define('ACCESS_TOKEN', '541085515-j3UFyYieL9jIlCT8cL12xI1ZzXHdjauQHnzp4A5j');
    define('ACCESS_SECRET', 'tHEKKl1ODRMRjZNTfNX01ggZf4psr2MpfHzZ8j6jHu5rm');

